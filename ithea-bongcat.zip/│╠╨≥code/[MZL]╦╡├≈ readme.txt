使用方法：双击文件夹内的Bongo Cat Mver，出问题试试以管理员身份打开
(unzip file and open Bongo Cat Mver.exe. If the exe cannot be opened, please try to open it with admin )
cat键盘上的12345既是大键盘上的，也是小键盘上的
鼠标镜像、变成桌宠等功能开BingiCatUI设置

呼出动画的快捷键必须要用大键盘数字

快捷键一览：
	表情（按一次开，按一次关）(tape twice to reset face)：
		CTRL+1	落寞张嘴 (depression 1)
		CTRL+2 	愉悦微笑 (smile)
		CTRL+3	落寞闭嘴 (depression 2)
		’	恢复默认
	动画（自动播放，可和表情重叠）(animation)：
		CTRL+7	脸红 (blush)
		CTRL+8	左眼WINK (wink)
		CTRL+9	哭哭脸 (crying)


——————————
作者（author）：MZL
如需商用邮箱联系（commercial use contact email address）：1229953662@qq.com